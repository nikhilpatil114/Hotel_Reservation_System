package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.entity.Category;
import com.app.entity.Railway;

public interface RailwayService {

	void Insert(Railway rail);

	List<Railway> GetAll();

	void Delete(int id);

	List<Railway> sorts();

	List<Railway> getRailwaysByCategory(Category category);

	void updateRailway(int id, Railway updatedRailway);

	Optional<Railway> findbyid(int id);

}
