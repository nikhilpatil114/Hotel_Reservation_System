package com.app.service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.Category;
import com.app.entity.Railway;
import com.app.repository.RailwayRepository;
@Service
public class RailwayServiceImpl implements RailwayService{

	@Autowired
    RailwayRepository railwayRepository;
	@Override
	public void Insert(Railway rail) {
		
	    railwayRepository.save(rail);
	}
	@Override
	public List<Railway> GetAll() {
		
		return railwayRepository.findAll();
	}
	@Override
	public void Delete(int id) {
		railwayRepository.deleteById(id);;
		
	}
	@Override
	public List<Railway> sorts() {
		List<Railway> rail=GetAll();
		rail.sort(Comparator.comparing((Railway r) -> r.getCategory().name()));
		return rail;
	}
	@Override
	 public List<Railway> getRailwaysByCategory(Category category) {
	        return railwayRepository.findByCategory(category);
	    }
	
	
	@Override
	public Optional<Railway> findbyid(int id) {
		return railwayRepository.findById(id);
		
	}
	@Override
	public void updateRailway(int id, Railway updatedRailway) {
		 Optional<Railway> optionalRailway = railwayRepository.findById(id);
	 
	            Railway existingRailway = optionalRailway.get();
	            existingRailway.setRid(updatedRailway.getRid());
	            existingRailway.setDestination(updatedRailway.getDestination());
	            existingRailway.setSource(updatedRailway.getSource());
	            existingRailway.setStime(updatedRailway.getStime());
	            existingRailway.setEtime(updatedRailway.getEtime());
	            existingRailway.setFreq(updatedRailway.getFreq());
	            existingRailway.setRname(updatedRailway.getRname());
	            existingRailway.setDistance(updatedRailway.getDistance());
	            existingRailway.setCategory(updatedRailway.getCategory());
	            // Update any other fields as needed
	            railwayRepository.save(existingRailway);
	         
		
	}

}
