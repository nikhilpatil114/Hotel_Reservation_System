package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.Category;
import com.app.entity.Railway;
@Repository
@Transactional
public interface RailwayRepository extends JpaRepository<Railway, Integer>{

	List<Railway> findByCategory(Category category);


}
