package com.app.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="railway")
public class Railway {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
   private int rid; 
   private String rname;
   private Category category;
   private LocalTime stime;
   private LocalTime etime;
   private String source;
   private String destination;
   private int distance;
   private int freq;
    
}
