package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.Category;
import com.app.entity.Railway;
import com.app.service.RailwayService;

@RestController
@RequestMapping("railway")
public class RailwayController {
@Autowired
RailwayService railwayService;
@PostMapping
public String Insert(@RequestBody Railway rail) {
	railwayService.Insert(rail);
	return "Data Inserted succesfull";
}
@GetMapping
public List<Railway>GetAll(){
	return railwayService.GetAll();
}
@DeleteMapping("/{id}")
public String Delete(@PathVariable int id) {
	railwayService.Delete(id);
	return "Delete Succesfull";
}
@GetMapping("/sorts")
public List<Railway> Sort(){
	return railwayService.sorts();
	
}
@GetMapping("/category/{category}")
public List<Railway> getRailwaysByCategory(@PathVariable Category category) {
    return railwayService.getRailwaysByCategory(category);
}
@PatchMapping("/{id}")
public String updateRailway(@PathVariable int id, @RequestBody Railway updatedRailway) {
    railwayService.updateRailway(id, updatedRailway);
    return "Update success";
}
@GetMapping("/find/{id}")
public Optional<Railway> findbyid(@PathVariable int id) {
	return railwayService.findbyid(id);
}
}
